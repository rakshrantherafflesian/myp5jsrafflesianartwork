let x
let c = 'white'
let mode = 1
let r = 10
let s1, cnv,thickness, a
function setup() {
  cnv = createCanvas(windowWidth, windowWidth);
  background(0);
  x = 255
   s1 = createSlider(1,100,1,1)
  s1.position(650, 40)
   a = 25
}


function draw() {
  if(keyIsPressed){
    if(keyCode == UP_ARROW){
      thickness = s1.value()
      thickness = thickness + 1
      
      s1.value(thickness)
     
    }
      if(keyCode == DOWN_ARROW){
      thickness = s1.value()
      thickness = thickness - 1
      
      s1.value(thickness)
    }
  }
  if(mouseIsPressed && mode==0 && mouseY> 120+s1.value()/2 && mouseY >=0 && pmouseY>120+s1.value()/2 && pmouseY>= 0){
    strokeWeight(0)
    fill(c)
    ellipse(mouseX,mouseY, s1.value(), s1. value())
  }
  else if(mouseIsPressed && mode == 1 && mouseY>120+s1.value()/2 && mouseY >= 0 && pmouseY>120+s1.value()/2 && pmouseY>= 0){
    strokeWeight(s1.value())
    stroke(c)
    line(mouseX, mouseY, pmouseX, pmouseY)
  }
  stroke(0)
  strokeWeight(1)
  fill('maroon')
  rect(10,10,30,30,5)
  fill('red')
  rect(10,50,30,30,5)
  fill('green')
  rect(50,10,30,30,5)
  fill('lime')
  rect(50,50,30,30,5)
  fill('olive')
  rect(90,10,30,30,5)
  fill('yellow')
  rect(90,50,30,30,5)
  fill('navy')
  rect(130,10,30,30,5)
  fill('blue')
  rect(130,50,30,30,5)
  fill('purple')
  rect(170,10,30,30,5)
  fill('fuchsia')
  rect(170,50,30,30,5)
  fill('teal')
  rect(210,10,30,30,5)
  fill('aqua')
  rect(210,50,30,30,5)
  fill('silver')
  rect(250,10,30,30,5)
  fill('gray')
  rect(250,50,30,30,5)
  fill('white')
  rect(290,10,30,30,5)
  fill(220,220,220)
  rect(330,10,70,70,5)
  rect(490,10,70,70,5)
  rect(570,10,70,70,5)
  fill('yellow')
  quad(330,30,350,10,400,60,380,80,5)
  fill('pink')
  quad(330,30,350,10,370,30,350,50)
  fill(220,220,220)
  rect(410,10,70,70,5)
  fill(255,203,164)
  triangle(420,20,460,80,480,60)
  fill('black')
  triangle(420,20,445,55,440,35)
  strokeWeight(5)
  line(605,20,605,55)
  line(605,55,585,40)
  line(605,55,625,40)
  line(585,60,625,60)
  
 
  stroke('red')
  strokeWeight(5)
  line(500,20,550,70)
  line(500,70,550,20)
  textSize(30)
  textFont('Times')
  textAlign(LEFT)
  stroke(0)
  fill(255)
  text('Colour Palette', 90,110)
  textAlign(CENTER)
  textSize(20)
  text('Eraser(e)', 365,110)
  text('Mode(m)', 445,110)
  text('Delete(d)', 525,110)
  text('Save(s)', 605,110)
  textSize(30)
  text('Thickness', 720,100)
  textSize(15)
  stroke(220)
  fill(0)
   text('free!', 605,75)
  stroke(255)
   line(0,120,width,120)
  textSize(15)
  strokeWeight(0)
  fill('white')
  text('q', a,30)
  text('r', a+40, 30) 
  text('y', a+80, 30) 
   text('i', a+120, 30)
  text('i', a+120, 30)
  text('p', a+160, 30)
  text('x', a+200, 30)
  text('x', a+200, 30)
   text('b', a+240, 70)
  
  fill('black')
  text('w', a, 70)
text('t', a+40, 70) 
  text('u', a+80, 70) 
   text('v', a+240, 30)
  text('o', a+120, 70) 
  
  text('z', a+160, 70) 
  
  text('c', a+200, 70)    
  
  text('n', a+280, 30) 
  
}
function mousePressed(){ 
  if(mouseX>410 && mouseX<480 && mouseY>10 && mouseY<80){
    if(mode== 0){
      mode =1
    }
    else if(mode == 1){
      mode = 0
    }
  }
  if(mouseX>570 && mouseX<640 && mouseY>10 && mouseY<80){
     save(cnv ,'Griffles, Waffles, Raffles Artwork.jpg') 
  }
  if(mouseX>490 && mouseX<560 && mouseY>10 && mouseY<80){
    background('black')
  }
  if(mouseX>r && mouseX<(r+30) && mouseY>10 && mouseY<(40)){
    c = 'maroon'
  }
 if(mouseX>r && mouseX<(r+30) && mouseY>50 && mouseY<(80)){
    c = ('red')
  }
  if(mouseX>r+40 && mouseX<(r+40+30) && mouseY>10 && mouseY<(40)){
    c = 'green'
  }
  if(mouseX>(r+40) && mouseX<(r+40+30) && mouseY>50 && mouseY<(80)){
    c = 'lime'
  }
  if(mouseX>(r+80) && mouseX<(r+80+30) && mouseY>10 && mouseY<(40)){
    c = 'olive'
  }
  if(mouseX>(r+80) && mouseX<(r+80+30) && mouseY>50 && mouseY<(80)){
    c = 'yellow'
  }
  if(mouseX>(r+120) && mouseX<(r+120+30) && mouseY>10 && mouseY<(40)){
    c = 'navy'
  }
    if(mouseX>(r+120) && mouseX<(r+120+30) && mouseY>50 && mouseY<(80)){
    c = 'blue'
  }
    if(mouseX>(r+160) && mouseX<(r+160+30) && mouseY>10 && mouseY<(40)){
    c = 'purple'
    }
   
   if(mouseX>(r+160) && mouseX<(r+160+30) && mouseY>50 && mouseY<(80)){
    c = 'fuchsia'
  }
   if(mouseX>(r+200) && mouseX<(r+200+30) && mouseY>10 && mouseY<(40)){
    c = 'teal'
  }
   if(mouseX>(r+200) && mouseX<(r+200+30) && mouseY>50 && mouseY<(80)){
    c = 'aqua'
  }
   if(mouseX>(r+240) && mouseX<(r+240+30) && mouseY>10 && mouseY<(40)){
    c = ('silver')
  }
   if(mouseX>(r+240) && mouseX<(r+240+30) && mouseY>50 && mouseY<(80)){
    c = 'gray'
  }
   if(mouseX>(r+280) && mouseX<(r+280+30) && mouseY>10 && mouseY<(40)){
    c = 'white'
  }
  
  if(mouseX>(330) && mouseX<(400) && mouseY>(10) && mouseY<(80)){
    c = ('black')
  }
  
}

function keyPressed(){
  if (key == 's'){
    save(cnv ,'theRafflesianArtwork.jpg')  
  }
 if (key == 'e'){
    c = ('black')
  }
  if (key == 'd'){
    background('black')
  }
  if (key == 'q'){
    c = ('maroon')
  }
   if (key == 'w'){
    c = ('red')
  }
   if (key == 'r'){
    c = ('green')
  }
   if (key == 't'){
    c = ('lime')
  }
   if (key == 'y'){
    c = ('olive')
  }
   if (key == 'u'){
    c = ('yellow')
  }
   if (key == 'i'){
    c = ('navy')
  }
   if (key == 'o'){
    c = ('blue')
  }
   if (key == 'p'){
    c = ('purple')
  }
   if (key == 'z'){
    c = ('fuchsia')
  }
   if (key == 'x'){
    c = ('teal')
  }
   if (key == 'c'){
    c = ('aqua')
  }
   if (key == 'v'){
    c = ('silver')
  }
   if (key == 'b'){
    c = ('gray')
  }
   if (key == 'n'){
    c = ('white')
  }
  if (key == 'm'){
    if(mode== 0){
      mode =1
    }
    else if(mode == 1){
      mode = 0
    }
    
  }
}
